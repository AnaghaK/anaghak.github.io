%f = figure(1)
%a = axes('Position',[0 0 2 2], 'Units','normalized', 'OuterPosition', [0 0 1 1]);
%imshow('background.png','Parent',a);
%set(imshow(RobotCar),'AlphaData',0.5);
%imshift('background.png', 500, 500)
%{
uniquebgcolor=[0 0 0]; % <- select a color that does not exist in your image!!!
RobotCar = imread('redcar.png','BackgroundColor',uniquebgcolor);
mask = bsxfun(@eq,RobotCar,reshape(uniquebgcolor,1,1,3));
image(RobotCar,'alphadata',1-double(all(mask,3)));
%}



%{
for k=1:9
h{k}=imread(sprintf('Slide0%d.png',k));
end
for k=10:20
h{k}=imread(sprintf('Slide%d.png',k));
end
save backgroundImages h

%}

%Images = {'Slide01.png'; 'Slide02.png'}
%I = montage(Images, 'Size', [2 1]);
%I = imread(imageMontage)

RobotCar0 = imresize(imread('redcar.jpg'), 0.55);
RobotCar1 = imresize(imread('redcarl.jpg'), 0.55);
RobotCar2 = imresize(imread('redcarr.jpg'), 0.55);
RobotCar3 = imresize(imread('redcarrl.jpg'), 0.55);
HumanCar = imresize(imread('greencar.jpg'), 0.55);
RobotCar = RobotCar0;
RobotCarPosition = [160, 505];
HumanCarPosition = [330, 115];
CarSizeRobot = [212, 109];
CarSizeHuman = [213, 108];

flagLeftLight = false;
flagRightLight = false;
flagTailLight = false;
leftStep     = 190;
rightStep    = 190;
stepUp = 20;
stepDown = 20;
leftSqueeze  = 65;
rightSqueeze = 65;

key = [];
set(gcf,'keypress','key=get(gcf,''currentchar'');');

%cd('background/');
I = imread('Slide02.jpg');
I1 = imread('Slide01.jpg');
counter = 0;

while 1
    counter = counter + 1;
    for i=1:10:530
        
        J1 = imtranslate(I1, [0, 0+i]);
        J = [I(531-i:540,:,:); J1(1+i:540,:,:)];
        J(RobotCarPosition(1):RobotCarPosition(1)+CarSizeRobot(1)-1,RobotCarPosition(2):RobotCarPosition(2)+CarSizeRobot(2)-1,:) = RobotCar;
        J(HumanCarPosition(1):HumanCarPosition(1)+CarSizeHuman(1)-1,HumanCarPosition(2):HumanCarPosition(2)+CarSizeHuman(2)-1,:) = HumanCar;
        imshow(J)
        
        if ~isempty(key)
            if strcmp(key, 'j')
                if flagTailLight == false
                    RobotCar = RobotCar1;
                    flagTailLight = true;
                else
                    RobotCar = RobotCar0;
                    flagTailLight = false;
                end
            elseif strcmp(key, 'k')
                if flagTailLight == false
                    RobotCar = RobotCar2;
                    flagTailLight = true;
                else
                    RobotCar = RobotCar0;
                    flagTailLight = false;
                end
            elseif strcmp(key, 'l')
                if flagTailLight == false
                    RobotCar = RobotCar3;
                    flagTailLight = true;
                else
                    RobotCar = RobotCar0;
                    flagTailLight = false;
                end
            elseif strcmp(key, 'a')
                RobotCarPosition(2) = max(RobotCarPosition(2)-leftSqueeze,70);  
            elseif strcmp(key, 'd')
                RobotCarPosition(2) = min(RobotCarPosition(2)+rightSqueeze,540); 
            elseif strcmp(key, 'e')
                RobotCarPosition(2) = max(RobotCarPosition(2)-leftStep,70);  
            elseif strcmp(key, 'r')
                RobotCarPosition(2) = min(RobotCarPosition(2)+rightStep,540);
            elseif strcmp(key, 'w')
                RobotCarPosition(1) = max(RobotCarPosition(1)-stepUp,11);  
            elseif strcmp(key, 'z')
                RobotCarPosition(1) = min(RobotCarPosition(1)+stepDown,335);
            elseif strcmp(key, 'q')
                return;
            end
            key = [];
        end
        
        randomValue = rand;
        
        if randomValue < 0.5
            HumanCarPosition(1) = min(HumanCarPosition(1)+5,300);
        else
            HumanCarPosition(1) = max(HumanCarPosition(1)-5,11);  
        end
        pause(0.5)
    end
    I = imread('Slide01.jpg');
    I1 = imread('Slide04.jpg');
    
    if(counter == 1)
        I1 = imread('Slide02.jpg');
    end
    
end



%{
image=imread('text.jpg');
[x,y]=size(image);
%}
%load the image
%I=imread('background.png');
%create a new axes
%h= axes('position',[0, 0, 2, 2], 'OuterPosition', [0, 0, 1, 1]);
%put an image on the axes
%imagesc(I);
%turn off the axis ticks and labels
%axis off
%plot the image 5 more times with a pause of 0.5 second
%for i=2:10
 %     pause(1)
      % update the position of the axis
  %    set(h,'position',[0,0,1,1*i])    
%end

%}
%uicontrol('Style','text','Units','Normalized','Position',[0.1 0.1 0.3 0.6],'String','Example');