RobotCar0 = imresize(imread('redcar.jpg'), 0.40);
RobotCar1 = imresize(imread('redcarl.jpg'), 0.40);
RobotCar2 = imresize(imread('redcarr.jpg'), 0.40);
RobotCar3 = imresize(imread('redcarrl.jpg'), 0.40);

SpareCar0 = imresize(imread('bluecar.jpg'), 0.40);
SpareCar1 = imresize(imread('bluecarl.jpg'), 0.40);
SpareCar2 = imresize(imread('bluecarr.jpg'), 0.40);
SpareCar3 = imresize(imread('bluecarrl.jpg'), 0.40);

HumanCar0 = imresize(imrotate(imread('greencar.jpg'), 90), 0.40);
HumanCar1 = imresize(imrotate(imread('greencarr.jpg'), 90), 0.40);
HumanCar2 = imresize(imrotate(imread('greencarl.jpg'), 90), 0.40);
HumanCar3 = imresize(imrotate(imread('greencarrl.jpg'), 90), 0.40);

RobotCar = RobotCar0;
HumanCar = HumanCar0;
SpareCar = SpareCar0;
RobotCarPosition = [386, 380];
HumanCarPosition = [140, 566];
SpareCarPosition = [265, 1];
CarSizeRobot = [154, 80];
CarSizeHuman = [79, 155];
CarSizeSpare = [78, 154];

flagLeftLight = false;
flagRightLight = false;
flagTailLight = false;
flagChangeDimensions = false;
leftStep     = 5;
rightStep    = 5;
stepUp = 5;
stepDown = 5;
leftSqueeze  = 65;
rightSqueeze = 65;

key = [];
set(gcf,'keypress','key=get(gcf,''currentchar'');');

%cd('background/');
J = imread('Slide21.png');
I = J;

while 1
    
    J(RobotCarPosition(1):RobotCarPosition(1)+CarSizeRobot(1)-1,RobotCarPosition(2):RobotCarPosition(2)+CarSizeRobot(2)-1,:) = RobotCar;
    J(HumanCarPosition(1):HumanCarPosition(1)+CarSizeHuman(1)-1,HumanCarPosition(2):HumanCarPosition(2)+CarSizeHuman(2)-1,:) = HumanCar;
    J(SpareCarPosition(1):SpareCarPosition(1)+CarSizeSpare(1)-1,SpareCarPosition(2):SpareCarPosition(2)+CarSizeSpare(2)-1,:) = SpareCar;

    imshow(J)
    
    if ~isempty(key)
        if strcmp(key, 'j')
            if flagTailLight == false
                RobotCar = RobotCar1;
                flagTailLight = true;
            else
                RobotCar = RobotCar0;
                flagTailLight = false;
            end
        elseif strcmp(key, 'k')
            if flagTailLight == false
                RobotCar = RobotCar2;
                flagTailLight = true;
            else
                RobotCar = RobotCar0;
                flagTailLight = false;
            end
        elseif strcmp(key, 'l')
            if flagTailLight == false
                RobotCar = RobotCar3;
                flagTailLight = true;
            else
                RobotCar = RobotCar0;
                flagTailLight = false;
            end
        elseif strcmp(key, 'e')
            RobotCar = imrotate(RobotCar, 90);
            if flagChangeDimensions == false
                CarSizeRobot = [80, 154];
                flagChangeDimensions = true;
            else
                CarSizeRobot = [154, 80];
                flagChangeDimensions = false;
            end
        elseif strcmp(key, 'r')
            RobotCar = imrotate(RobotCar, 270);
            if flagChangeDimensions == false
                CarSizeRobot = [80, 154];
                flagChangeDimensions = true;
            else
                CarSizeRobot = [154, 80];
                flagChangeDimensions = false;
            end
        elseif strcmp(key, 'w')
            RobotCarPosition(1) = max(RobotCarPosition(1)-stepUp,9);  
        elseif strcmp(key, 'z')
            RobotCarPosition(1) = min(RobotCarPosition(1)+stepDown,375);
        elseif strcmp(key, 'a')
            RobotCarPosition(2) = max(RobotCarPosition(2)-leftStep,11);  
        elseif strcmp(key, 'd')
            RobotCarPosition(2) = min(RobotCarPosition(2)+rightStep,500);
        elseif strcmp(key, 'q')
            return;
        end
        key = [];
    end
    
    HumanCarPosition(2) = max(HumanCarPosition(2)-3,11);
    SpareCarPosition(2) = min(SpareCarPosition(2)+3,540);
    J = I;

    pause(0.3)
    
end
